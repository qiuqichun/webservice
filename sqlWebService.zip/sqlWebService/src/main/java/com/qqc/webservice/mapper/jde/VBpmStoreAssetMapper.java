package com.qqc.webservice.mapper.jde;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.qqc.webservice.entity.VBpmStoreAssetEntity;

public interface VBpmStoreAssetMapper {

	public List<VBpmStoreAssetEntity> queryBpmStoreAssetInfo(@Param("storeNo") String storeNo);
}
