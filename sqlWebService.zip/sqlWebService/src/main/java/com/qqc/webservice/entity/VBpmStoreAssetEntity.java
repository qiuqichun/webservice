package com.qqc.webservice.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;


/**
 * v_bpm_store_asset
 * @author Administrator
 *
 */
public class VBpmStoreAssetEntity implements Serializable{
	private static final long serialVersionUID = -3668093008576470842L;
	private String storeNo;
	private Integer assetNo;
	private String assetName;
	private String assetFormat;
	private String assetStatus;
	private Date assetJoinDate;
	private BigDecimal assetValue;
	private BigDecimal assetLose;
	private BigDecimal assetRemain;
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public Integer getAssetNo() {
		return assetNo;
	}
	public void setAssetNo(Integer assetNo) {
		this.assetNo = assetNo;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetFormat() {
		return assetFormat;
	}
	public void setAssetFormat(String assetFormat) {
		this.assetFormat = assetFormat;
	}
	public String getAssetStatus() {
		return assetStatus;
	}
	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}
	public Date getAssetJoinDate() {
		return assetJoinDate;
	}
	public void setAssetJoinDate(Date assetJoinDate) {
		this.assetJoinDate = assetJoinDate;
	}
	public BigDecimal getAssetValue() {
		return assetValue;
	}
	public void setAssetValue(BigDecimal assetValue) {
		this.assetValue = assetValue;
	}
	public BigDecimal getAssetLose() {
		return assetLose;
	}
	public void setAssetLose(BigDecimal assetLose) {
		this.assetLose = assetLose;
	}
	public BigDecimal getAssetRemain() {
		return assetRemain;
	}
	public void setAssetRemain(BigDecimal assetRemain) {
		this.assetRemain = assetRemain;
	}
	
	
	
}
