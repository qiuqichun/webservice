package com.qqc.webservice.config.dataSource;

import javax.sql.DataSource;

import org.apache.ibatis.plugin.Interceptor;
import org.apache.ibatis.session.SqlSessionFactory;
import org.apache.log4j.Logger;
import org.mybatis.spring.SqlSessionFactoryBean;
import org.mybatis.spring.SqlSessionTemplate;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Primary;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.jdbc.datasource.DataSourceTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.qqc.webservice.config.DsConfig;
import com.qqc.webservice.config.PageHelperConfig;

@Configuration
@EnableTransactionManagement
@MapperScan(basePackages = "com.qqc.webservice.mapper.assets", sqlSessionTemplateRef = DsConfig.ASSETS
		+ "SqlSessionTemplate")
public class DataSourceConfigAssets {

	private final Logger logger = Logger.getLogger(DataSourceConfigAssets.class);

	@Primary
	@Bean(name = DsConfig.ASSETS + "SqlSessionFactory")
	public SqlSessionFactory sqlSessionFactory(@Qualifier(DsConfig.ASSETS + "DataSource") DataSource dataSource)
			throws Exception {
		logger.info("setSqlSessionFactory()...");
		SqlSessionFactoryBean bean = new SqlSessionFactoryBean();
		bean.setDataSource(dataSource);
		bean.setMapperLocations(new PathMatchingResourcePatternResolver()
				.getResources("classpath:mapping/" + DsConfig.ASSETS + "/*.xml"));
		// 添加插件
		bean.setPlugins(new Interceptor[] { PageHelperConfig.pageHelper() });
		return bean.getObject();
	}

	@Bean(name = DsConfig.ASSETS + "TransactionManager")
	@Primary
	public DataSourceTransactionManager setTransactionManager(
			@Qualifier(DsConfig.ASSETS + "DataSource") DataSource dataSource) {
		logger.info("setTransactionManager()...");
		return new DataSourceTransactionManager(dataSource);
	}

	@Bean(DsConfig.ASSETS + "SqlSessionTemplate")
	@Primary
	public SqlSessionTemplate setSqlSessionTemplate(
			@Qualifier(DsConfig.ASSETS + "SqlSessionFactory") SqlSessionFactory sqlSessionFactory) throws Exception {
		logger.info("setSqlSessionTemplate()...");
		return new SqlSessionTemplate(sqlSessionFactory);
	}

	/*
	 * @Bean(name = "jdbcTemplate")
	 * 
	 * @Primary public JdbcTemplate setJdbcTemplate(@Qualifier("dataSource")
	 * DataSource dataSource) { logger.info("setJdbcTemplate()..."); return new
	 * JdbcTemplate(dataSource); }
	 */

}
