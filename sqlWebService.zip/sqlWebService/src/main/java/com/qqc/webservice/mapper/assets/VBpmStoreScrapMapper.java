package com.qqc.webservice.mapper.assets;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.qqc.webservice.entity.VBpmStoreScrapEntity;

public interface VBpmStoreScrapMapper {
	
	public List<VBpmStoreScrapEntity> queryBpmStoreScrapInfo(@Param("orderDateBegin") String orderDateBegin,@Param("orderDateEnd") String orderDateEnd,@Param("storeNo") List<String> storeNo);
	
}
