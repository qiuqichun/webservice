package com.qqc.webservice.config;

import javax.xml.ws.Endpoint;

import org.apache.cxf.Bus;
import org.apache.cxf.bus.spring.SpringBus;
import org.apache.cxf.jaxws.EndpointImpl;
import org.apache.cxf.transport.servlet.CXFServlet;
import org.springframework.boot.web.servlet.ServletRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.qqc.webservice.service.BpmStoreService;
import com.qqc.webservice.service.impl.BpmStoreServiceImpl;

/**
 * 整合webservice
 * 
 * @author Administrator
 *
 */
@Configuration
public class CXFConfig {
	/**
	 * webservice 请求拦截地址
	 * 
	 * @return
	 */
	@Bean
	public ServletRegistrationBean dispatcherServlet() {
		return new ServletRegistrationBean(new CXFServlet(), "/bpm/*");
	}

	@Bean(name = Bus.DEFAULT_BUS_ID)
	public SpringBus springBus() {
		return new SpringBus();
	}

	@Bean
	public BpmStoreService bpmStoreService() {
		return new BpmStoreServiceImpl();
	}

	@Bean
	public Endpoint endpoint() {
		EndpointImpl endpoint = new EndpointImpl(springBus(), bpmStoreService());
		endpoint.publish("/bpmStore");
		// endpoint.getInInterceptors().add(new WsInterceptor()); //add webservice inteceptor
		return endpoint;
	}
}
