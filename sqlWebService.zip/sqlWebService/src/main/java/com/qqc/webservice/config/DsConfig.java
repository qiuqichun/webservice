package com.qqc.webservice.config;


public class DsConfig {

    //oracle数据库
    public static final String JDE = "jde";
    //sqlserver数据库
    public static final String ASSETS = "assets";
}
