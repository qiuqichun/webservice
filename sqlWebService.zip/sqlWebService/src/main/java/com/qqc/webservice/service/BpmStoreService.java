package com.qqc.webservice.service;

import java.util.List;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;

import com.qqc.webservice.entity.VBpmStoreAssetEntity;
import com.qqc.webservice.entity.VBpmStoreScrapEntity;

@WebService
public interface BpmStoreService {
	@WebMethod
	public List<VBpmStoreAssetEntity> queryBpmStoreAssetInfo(@WebParam(name = "storeNo") String storeNo);
	
	@WebMethod
	public List<VBpmStoreScrapEntity> queryBpmStoreScrapInfo(@WebParam(name = "orderDateBegin") String orderDateBegin,@WebParam(name = "orderDateEnd") String orderDateEnd,@WebParam(name = "storeNo") List<String> storeNo);
	

}
