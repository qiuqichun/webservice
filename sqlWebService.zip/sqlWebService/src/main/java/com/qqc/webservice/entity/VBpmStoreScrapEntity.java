package com.qqc.webservice.entity;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * V_BPM_STORE_SCRAP
 * @author Administrator
 *
 */
public class VBpmStoreScrapEntity implements Serializable{

	private static final long serialVersionUID = -7739471650767295102L;
	
	private Date orderDate;
	private String storeNo;
	private String storeName;
	private String assetNo;
	private String assetName;
	private String assetFormat;
	private BigDecimal assetRemain;
	private String assetStatus;
	private String orderNo;
	private String deptNo;
	private String deptName;
	public Date getOrderDate() {
		return orderDate;
	}
	public void setOrderDate(Date orderDate) {
		this.orderDate = orderDate;
	}
	public String getStoreNo() {
		return storeNo;
	}
	public void setStoreNo(String storeNo) {
		this.storeNo = storeNo;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getAssetNo() {
		return assetNo;
	}
	public void setAssetNo(String assetNo) {
		this.assetNo = assetNo;
	}
	public String getAssetName() {
		return assetName;
	}
	public void setAssetName(String assetName) {
		this.assetName = assetName;
	}
	public String getAssetFormat() {
		return assetFormat;
	}
	public void setAssetFormat(String assetFormat) {
		this.assetFormat = assetFormat;
	}
	public BigDecimal getAssetRemain() {
		return assetRemain;
	}
	public void setAssetRemain(BigDecimal assetRemain) {
		this.assetRemain = assetRemain;
	}
	public String getAssetStatus() {
		return assetStatus;
	}
	public void setAssetStatus(String assetStatus) {
		this.assetStatus = assetStatus;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getDeptNo() {
		return deptNo;
	}
	public void setDeptNo(String deptNo) {
		this.deptNo = deptNo;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	
	

}
