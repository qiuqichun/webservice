package com.qqc.webservice.controller;

import java.util.ArrayList;
import java.util.List;

import org.apache.cxf.jaxws.endpoint.dynamic.JaxWsDynamicClientFactory;

import com.google.gson.Gson;

public class Client {
	public static void main(String args[]) throws Exception {

		JaxWsDynamicClientFactory dcf = JaxWsDynamicClientFactory.newInstance();
		org.apache.cxf.endpoint.Client client = dcf.createClient("http://localhost:8077/sqlWebService/bpm/bpmStore?wsdl");
		Object[] objects = client.invoke("queryBpmStoreAssetInfo", "  1100234500");
		// 输出调用结果
		System.out.println("测试返回报文：" + new Gson().toJson(objects));
		
		
		
		org.apache.cxf.endpoint.Client client2 = dcf.createClient("http://localhost:8077/sqlWebService/bpm/bpmStore?wsdl");
		
		List<String> a = new ArrayList<String>();
		a.add("1100215201");
		a.add("2100306603");
		Object[] objects2 = client2.invoke("queryBpmStoreScrapInfo", "2018/12/01","2018/12/07",a);
		// 输出调用结果
		System.out.println("测试返回报文：" + new Gson().toJson(objects));
		System.out.println("测试返回报文：" + new Gson().toJson(objects2));
	}
	
	
}
