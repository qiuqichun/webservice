package com.qqc.webservice.service.impl;

import java.util.List;

import javax.jws.WebService;

import org.springframework.beans.factory.annotation.Autowired;

import com.qqc.webservice.entity.VBpmStoreAssetEntity;
import com.qqc.webservice.entity.VBpmStoreScrapEntity;
import com.qqc.webservice.mapper.assets.VBpmStoreScrapMapper;
import com.qqc.webservice.mapper.jde.VBpmStoreAssetMapper;
import com.qqc.webservice.service.BpmStoreService;

@WebService(targetNamespace="http://service.webservice.qqc.com/",endpointInterface = "com.qqc.webservice.service.BpmStoreService")
public class BpmStoreServiceImpl implements BpmStoreService{
	@Autowired
	public VBpmStoreScrapMapper userMapper;
	
	@Autowired
	public VBpmStoreAssetMapper userTestMapper;
	

	@Override
	public List<VBpmStoreAssetEntity> queryBpmStoreAssetInfo(String storeNo) {
		return this.userTestMapper.queryBpmStoreAssetInfo(storeNo);
	}


	@Override
	public List<VBpmStoreScrapEntity> queryBpmStoreScrapInfo(String orderDateBegin, String orderDateEnd,
			List<String> storeNo) {
		return userMapper.queryBpmStoreScrapInfo(orderDateBegin, orderDateEnd, storeNo);
	}

	
	
}
